() => {
  if (window.hasRun) {
    return;
  }
  window.hasRun = true;
};
