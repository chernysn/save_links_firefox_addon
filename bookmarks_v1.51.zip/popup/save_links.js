function getCurrentTabUrl(callback) {
  var queryInfo = { active: true, currentWindow: true };

  browser.tabs.query(queryInfo, function (tabs) {
    var tab = tabs[0];
    var tabInfo = {
      url: tab.url,
      title: tab.title,
    };
    callback(tabInfo);
  });
}

getCurrentTabUrl(function (tabInfo) {
  document.getElementById("link").value = tabInfo.url;
  document.getElementById("title").value = tabInfo.title;
});

var all_links = [];

async function run() {
  const storageData_display = await browser.storage.local.get("links_saved");
  const links_saved_display = storageData_display["links_saved"] || {};
  displayOnPage(links_saved_display);
  displayTags();
}

async function displayTags() {
  let tagsToSelect = [];

  const storageData = await browser.storage.local.get("links_saved");
  const links_saved = storageData["links_saved"] || {};

  if (links_saved.length == 0) {
    tagsToSelect = ["work", "visit", "soccer"];
  } else {
    for (let title in links_saved) {
      let link = links_saved[title].tags;
      if (!tagsToSelect.includes(link) && link !== "") {
        tagsToSelect.push(link);
      }
    }
  }
  var tagsField = document.querySelector(".tags-field");
  if (tagsToSelect !== "") {
    tagsField.innerHTML = "";
    tagsToSelect.forEach((tag) => {
      let tagsDiv = document.createElement("div");
      tagsDiv.textContent = tag;
      tagsDiv.classList.add("tag-div");
      tagsDiv.onclick = function () {
        searchByTag(tag);
      };
      tagsField.appendChild(tagsDiv);
    });
    all_tags = document.querySelectorAll(".tag-div");
  }
}

async function displayOnPage(links) {
  output_items.innerHTML = "";
  if (links.length === 0) {
    output_items.innerHTML = "<br><p>No messages to display yet ... </p>";
  } else {
    Object.values(links).forEach((link) => {
      let li = document.createElement("li");
      let text = `<p class="address"><a href="${link.address}">${link.title}</a></p>
      <p>${link.comment}</p> <p class="remove">remove</p>`;

      li.innerHTML = text;
      output_items.appendChild(li);
    });

    var removeItems = document.querySelectorAll(".remove");

    removeItems.forEach((item, index) => {
      item.addEventListener("click", async () => {
        let removed = Object.values(links);
        removed.splice(index, 1);
        await browser.storage.local.set({ links_saved: removed });
        displayOnPage(removed);
        displayTags();
      });
    });
  }
}

var btn = document.getElementById("save");
var output_items = document.querySelector(".output_list");

btn.addEventListener("click", async () => {
  let storageData = await browser.storage.local.get("links_saved");
  all_links = storageData.links_saved || [];

  let address = document.getElementById("link").value;
  let comment = document.getElementById("description").value;
  let title = document.getElementById("title").value;
  let getTag = tags.value;

  let titleExists = false;

  for (i = 0; i < all_links.length; i++) {
    if (all_links[i].title === title) {
      all_links[i] = {
        address: address,
        title: title,
        comment: comment,
        tags: getTag,
      };
      titleExists = true;
      break;
    }
  }

  if (!titleExists) {
    all_links.push({
      address: address,
      title: title,
      comment: comment,
      tags: getTag,
    });
  }

  await browser.storage.local.set({ links_saved: all_links });
  let getLinks = await browser.storage.local.get("links_saved");
  all_links = getLinks.links_saved || [];
  displayOnPage(all_links);

  document.getElementById("description").value = "";
  document.getElementById("tags").value = "";
  displayTags();
});

async function searchByTag(tag) {
  const storageData = await browser.storage.local.get("links_saved");
  all_links = storageData.links_saved || [];
  const foundLinks = [];
  all_links.forEach((link) => {
    if (link.tags === tag) {
      foundLinks.push(link);
    }
  });

  displayOnPage(foundLinks);
  displayTags();
}

run();
